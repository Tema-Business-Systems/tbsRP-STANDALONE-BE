package com.transport.tracking.k.service;


import org.springframework.stereotype.Component;

@Component
public class CreatePojo {



}
